-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 15, 2010 at 11:13 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `advance_ta`
--

CREATE TABLE `advance_ta` (
  `sno` int(10) NOT NULL auto_increment,
  `user_name` varchar(20) NOT NULL,
  `training_name` varchar(50) NOT NULL,
  `chap_name` varchar(25) NOT NULL,
  `last_accessed` datetime default NULL,
  `exercise` varchar(10) NOT NULL,
  `progress` int(5) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `slide_no` int(5) NOT NULL,
  PRIMARY KEY  (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `advance_ta`
--

INSERT INTO `advance_ta` (`sno`, `user_name`, `training_name`, `chap_name`, `last_accessed`, `exercise`, `progress`, `grade`, `slide_no`) VALUES
(1, 'ajay123', 'Level 2 - Advanced', 'Module5', '2010-04-15 14:25:57', '', 95, '', 20),
(2, 'ajay123', 'Level 2 - Advanced', 'Module6', '2010-04-15 12:53:04', '', 4, '', 1),
(3, 'ajay123', 'Level 2 - Advanced', 'Module7', '2010-04-15 16:13:19', '', 12, '', 4),
(4, 'ajay123', 'Level 2 - Advanced', 'Module8', NULL, '', 0, '', 0),
(5, 'ajay123', 'Level 2 - Advanced', 'Module9', NULL, '', 0, '', 0),
(6, 'ajay123', 'Level 2 - Advanced', 'Module10', NULL, '', 0, '', 0),
(7, 'ajay123', 'Level 2 - Advanced', 'Module11', NULL, '', 0, '', 0),
(8, 'ajay123', 'Level 2 - Advanced', 'Module12', NULL, '', 0, '', 0),
(9, 'ajay123', 'Level 2 - Advanced', 'Module13', NULL, '', 0, '', 0),
(10, 'ajay123', 'Level 2 - Advanced', 'Module14', NULL, '', 0, '', 0),
(11, 'ajay123', 'Level 2 - Advanced', 'Module15', NULL, '', 0, '', 0),
(12, 'ajay123', 'Level 2 - Advanced', 'Module16', NULL, '', 0, '', 0),
(13, 'ajay123', 'Level 2 - Advanced', 'Module17', NULL, '', 0, '', 0),
(14, 'ajay123', 'Level 2 - Advanced', 'Module18', NULL, '', 0, '', 0),
(15, 'ajay123', 'Level 2 - Advanced', 'Module19', NULL, '', 0, '', 0),
(16, 'paul', 'Level 2 - Advanced', 'Module5', NULL, '', 0, '', 0),
(17, 'paul', 'Level 2 - Advanced', 'Module6', NULL, '', 0, '', 0),
(18, 'paul', 'Level 2 - Advanced', 'Module7', NULL, '', 0, '', 0),
(19, 'paul', 'Level 2 - Advanced', 'Module8', NULL, '', 0, '', 0),
(20, 'paul', 'Level 2 - Advanced', 'Module9', NULL, '', 0, '', 0),
(21, 'paul', 'Level 2 - Advanced', 'Module10', NULL, '', 0, '', 0),
(22, 'paul', 'Level 2 - Advanced', 'Module11', NULL, '', 0, '', 0),
(23, 'paul', 'Level 2 - Advanced', 'Module12', NULL, '', 0, '', 0),
(24, 'paul', 'Level 2 - Advanced', 'Module13', NULL, '', 0, '', 0),
(25, 'paul', 'Level 2 - Advanced', 'Module14', NULL, '', 0, '', 0),
(26, 'paul', 'Level 2 - Advanced', 'Module15', NULL, '', 0, '', 0),
(27, 'paul', 'Level 2 - Advanced', 'Module16', NULL, '', 0, '', 0),
(28, 'paul', 'Level 2 - Advanced', 'Module17', NULL, '', 0, '', 0),
(29, 'paul', 'Level 2 - Advanced', 'Module18', NULL, '', 0, '', 0),
(30, 'paul', 'Level 2 - Advanced', 'Module19', NULL, '', 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `basic_ta`
--

CREATE TABLE `basic_ta` (
  `sno` int(10) NOT NULL auto_increment,
  `user_name` varchar(20) NOT NULL,
  `training_name` varchar(50) NOT NULL,
  `chap_name` varchar(25) NOT NULL,
  `last_accessed` datetime default NULL,
  `exercise` varchar(10) NOT NULL,
  `progress` int(5) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `slide_no` int(5) NOT NULL,
  PRIMARY KEY  (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `basic_ta`
--

INSERT INTO `basic_ta` (`sno`, `user_name`, `training_name`, `chap_name`, `last_accessed`, `exercise`, `progress`, `grade`, `slide_no`) VALUES
(1, 'ajay123', 'Level 1 - Basic', 'Module1', '2010-04-12 10:26:59', '', 93, '', 26),
(2, 'ajay123', 'Level 1 - Basic', 'Module2', '2010-04-13 18:00:13', '', 19, '', 6),
(3, 'ajay123', 'Level 1 - Basic', 'Module3', '2010-04-14 13:33:14', '', 79, '', 27),
(4, 'ajay123', 'Level 1 - Basic', 'Module4', '2010-04-14 11:38:35', '', 100, '', 27),
(5, 'ajay', 'Level 1 - Basic', 'Module1', '2010-03-26 11:48:15', '', 68, '', 15),
(6, 'ajay', 'Level 1 - Basic', 'Module2', '2010-02-20 15:34:45', '', 0, '', 0),
(7, 'ajay', 'Level 1 - Basic', 'Module3', '2010-02-20 17:26:55', '', 100, '', 32),
(8, 'ajay', 'Level 1 - Basic', 'Module4', '2010-02-20 17:26:04', '', 8, '', 2),
(9, 'paul', 'Level 1 - Basic', 'Module1', NULL, '', 0, '', 0),
(10, 'paul', 'Level 1 - Basic', 'Module2', NULL, '', 0, '', 0),
(11, 'paul', 'Level 1 - Basic', 'Module3', NULL, '', 0, '', 0),
(12, 'paul', 'Level 1 - Basic', 'Module4', NULL, '', 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE `batch` (
  `sno` int(11) NOT NULL auto_increment,
  `batchid` varchar(100) NOT NULL,
  `limit1` int(11) NOT NULL,
  `days` varchar(100) NOT NULL,
  `time1` varchar(100) NOT NULL,
  `course` varchar(200) NOT NULL,
  `duration` int(11) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date default NULL,
  PRIMARY KEY  (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`sno`, `batchid`, `limit1`, `days`, `time1`, `course`, `duration`, `startdate`, `enddate`) VALUES
(1, 'B-1', 15, 'MWF', '7-8 AM', 'Ms-Office', 1, '2009-09-01', '2009-09-30'),
(2, 'B-2', 24, 'MWF', '7-8 AM', 'Flash', 15, '2009-10-01', '2009-10-14'),
(3, 'B-3', 40, 'MWF', '7-8 AM', 'Visual Basic', 3, '2009-11-01', '2010-01-31');

-- --------------------------------------------------------

--
-- Table structure for table `batch_dtime`
--

CREATE TABLE `batch_dtime` (
  `days` varchar(100) NOT NULL,
  `time1` varchar(100) NOT NULL,
  `totalstudent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch_dtime`
--


-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `sno` int(11) NOT NULL auto_increment,
  `course_name` varchar(100) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `course_id` varchar(100) NOT NULL,
  PRIMARY KEY  (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`sno`, `course_name`, `duration`, `type`, `course_id`) VALUES
(1, 'Ms-Office', '1', 'M', 'ms001'),
(2, 'Visual Basic', '3', 'M', 'vb002'),
(3, 'Flash', '15', 'D', 'flash001'),
(4, 'PhotoShop', '3', 'M', 'photoshop1');

-- --------------------------------------------------------

--
-- Table structure for table `institutes`
--

CREATE TABLE `institutes` (
  `sno` int(11) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `institute_type` int(11) NOT NULL,
  `code` varchar(200) NOT NULL,
  PRIMARY KEY  (`sno`),
  KEY `sno` (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `institutes`
--

INSERT INTO `institutes` (`sno`, `name`, `institute_type`, `code`) VALUES
(1, 'RKMV Shimla', 1, 'C-1'),
(2, 'GC Seema', 1, 'C-2'),
(3, 'GC Rampur', 1, 'C-3'),
(4, 'GC Sanjauli', 1, 'C-4'),
(5, 'GC Chaura Maidan', 1, 'C-5'),
(6, 'GC Theog', 1, 'C-6'),
(7, 'GC Saraswatinagar', 1, 'C-7'),
(8, 'GSSS Suni', 2, 'S-1'),
(9, 'GSSS Rampur(B)', 2, 'S-2'),
(10, 'GSSS Theog(B)', 2, 'S-3'),
(11, 'GSSS Rampur(G)', 2, 'S-4'),
(12, 'GSSS Chhota Shimla', 2, 'S-5'),
(13, 'GSSS Lakkar Bazar', 2, 'S-6'),
(14, 'GSSS Portmore(G)', 2, 'S-7'),
(15, 'GSSS Sanjauli', 2, 'S-8'),
(16, 'GSSS Shimla(B)', 2, 'S-9');

-- --------------------------------------------------------

--
-- Table structure for table `institute_name`
--

CREATE TABLE `institute_name` (
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `institute_name`
--

INSERT INTO `institute_name` (`name`) VALUES
('GSSS Suni');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `sno` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `code` int(11) NOT NULL,
  PRIMARY KEY  (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`sno`, `username`, `password`, `code`) VALUES
(1, 'GSSSSUNI', 'GSSSSUNI', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student_batch`
--

CREATE TABLE `student_batch` (
  `batchid` varchar(100) NOT NULL,
  `Student_id` varchar(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `batchtime` varchar(100) NOT NULL,
  `batchdays` varchar(100) NOT NULL,
  `batchdate` date NOT NULL,
  `totalenroll` int(11) NOT NULL,
  `course` varchar(100) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_batch`
--

INSERT INTO `student_batch` (`batchid`, `Student_id`, `name`, `batchtime`, `batchdays`, `batchdate`, `totalenroll`, `course`) VALUES
('B-2', 'S-1-1', 'Manoj Satywali', '7-8 AM', 'MWF', '0000-00-00', 0, 'Ms-Office'),
('B-1', 'S-1-2', 'Ajay Sharma', '7-8 AM', 'MWF', '0000-00-00', 0, 'Ms-Office'),
('B-1', 'S-1-3', 'Sanjay Kothari', '7-8 AM', 'MWF', '0000-00-00', 0, 'Ms-Office');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `sno` int(11) NOT NULL auto_increment,
  `Student_name` varchar(100) NOT NULL,
  `User_name` varchar(20) NOT NULL,
  `password` varchar(12) NOT NULL,
  `Class` varchar(20) NOT NULL,
  `Category` varchar(20) NOT NULL,
  `Contact_no` varchar(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `institute_name` varchar(200) NOT NULL,
  `Student_id` varchar(100) NOT NULL,
  `batchcode` varchar(100) default NULL,
  `last_accessed` datetime NOT NULL,
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`sno`, `Student_name`, `User_name`, `password`, `Class`, `Category`, `Contact_no`, `Email`, `institute_name`, `Student_id`, `batchcode`, `last_accessed`) VALUES
(1, 'Manoj Satywali', 'manojsatywali', '12345', '10th', 'science', '9540097170', 'manoj.satywali@planetdewsoft.com', 'GSSS Suni', 'S-1-1', 'B-2', '0000-00-00 00:00:00'),
(2, 'Ajay Sharma', 'ajay', '1234', '10th', 'Arts', '9585828585', 'ajay.sharma@planetdewsoft.com', 'GSSS Suni', 'S-1-2', 'B-1', '2010-03-26 16:01:22'),
(3, 'Sanjay Kothari', 'kothari', '12345', '10th', 'arts', '1234567899', '', 'GSSS Suni', 'S-1-3', 'B-1', '0000-00-00 00:00:00'),
(4, 'Prakash Singh', 'prakash', '12345', '12th', 'arts', '2121212121', '', 'GSSS Suni', 'S-1-4', NULL, '0000-00-00 00:00:00'),
(5, 'Vivek Paul', 'paul', '123', '12th', 'commercer', '1245845444', 'vivek.paul@planetdewsoft.com', 'GSSS Suni', 'S-1-5', NULL, '2010-04-14 14:31:00'),
(6, 'Rajeev Kumar', 'rajeev', '12345', '10th', 'arts', '05245245145', 'rajeev@rediffmail.com', 'GSSS Suni', 'S-1-6', NULL, '0000-00-00 00:00:00'),
(7, 'Ajay singh', 'ajay123', '123', '8th', 'science', '9899895797', '', 'GSSS Suni', 'S-1-7', NULL, '2010-04-15 16:12:38');

-- --------------------------------------------------------

--
-- Table structure for table `t_group`
--

CREATE TABLE `t_group` (
  `sno` int(4) NOT NULL auto_increment,
  `training_time` varchar(70) NOT NULL,
  `recommended_time` varchar(70) NOT NULL,
  `group_name` varchar(70) NOT NULL,
  PRIMARY KEY  (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `t_group`
--

INSERT INTO `t_group` (`sno`, `training_time`, `recommended_time`, `group_name`) VALUES
(1, '150', '170', 'Level 1 - Basic'),
(2, '145', '155', 'Level 2 - Advanced'),
(3, '135', '145', 'Level 3 - Expert');

-- --------------------------------------------------------

--
-- Table structure for table `user_track`
--

CREATE TABLE `user_track` (
  `sno` int(11) NOT NULL auto_increment,
  `training_id` int(200) default NULL,
  `user_name` varchar(200) NOT NULL,
  `training_name` varchar(200) default NULL,
  `training_time` varchar(200) default NULL,
  `recommendate_time` varchar(200) default NULL,
  `exercise` varchar(100) NOT NULL,
  `last_accessed` datetime default NULL,
  `grade` varchar(10) default NULL,
  `progress` int(11) default NULL,
  `institute_name` varchar(200) NOT NULL,
  `Student_id` varchar(200) NOT NULL,
  `slide_no` int(11) NOT NULL default '0',
  PRIMARY KEY  (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user_track`
--

INSERT INTO `user_track` (`sno`, `training_id`, `user_name`, `training_name`, `training_time`, `recommendate_time`, `exercise`, `last_accessed`, `grade`, `progress`, `institute_name`, `Student_id`, `slide_no`) VALUES
(1, NULL, 'manojsatywali', 'English to Hindi', NULL, NULL, 'NO', NULL, NULL, 0, 'GSSS Suni', 'S-1-1', 0),
(2, NULL, 'ajay', 'English to Hindi', NULL, NULL, 'NO', '2009-11-07 13:41:31', NULL, 0, 'GSSS Suni', 'S-1-2', 0),
(3, NULL, 'kothari', 'English to Hindi', NULL, NULL, 'NO', NULL, NULL, 0, 'GSSS Suni', 'S-1-3', 0),
(4, NULL, 'prakash', 'English to Hindi', NULL, NULL, 'NO', NULL, NULL, 0, 'GSSS Suni', 'S-1-4', 0),
(5, NULL, 'paul', 'English to Hindi', NULL, NULL, 'NO', '2009-10-20 17:22:36', NULL, 33, 'GSSS Suni', 'S-1-5', 1),
(6, NULL, 'rajeev', 'English to Hindi', NULL, NULL, 'NO', '2009-10-20 17:45:07', NULL, 100, 'GSSS Suni', 'S-1-6', 3),
(7, NULL, 'ajay123', 'English to Hindi', NULL, NULL, 'NO', '2009-11-05 15:06:52', NULL, 33, 'GSSS Suni', 'S-1-7', 4);
